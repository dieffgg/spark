import os, sys
import cgitb; cgitb.enable()
from spark.ReqBase import ReqBase
def spark_req_run(): ReqBase().run()

